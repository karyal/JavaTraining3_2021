/**
 * 
 */
function test(){
	alert("Hello from test()");
}