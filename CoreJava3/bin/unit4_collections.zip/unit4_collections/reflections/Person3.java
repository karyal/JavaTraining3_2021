package collections.reflections;

public class Person3 {
	private String name;
}
