package collections.reflections;

public class Person2 {
	public int pid=1;
	public String name="Raj";
	public String address="KTM";
	
}
