package collections.generics;

public class Main {
	public static void main(String[] args) {
		/*
		//Example-1
		Example1 obj1 = new Example1();
		String str="Hello";
		obj1.set(str);
		System.out.println(obj1.get());
		
		int n1 = 25;
		obj1= new Example1();
		obj1.set(n1);
		int n2 = Integer.parseInt(obj1.get().toString());
		System.out.println(n2);
		
		
		
		//Example-2
		Example1 obj1 = new Example1();
		obj1.set("Kathmandu");
		System.out.println(obj1.get());		
		obj1.set(123);
		System.out.println(obj1.get());
		obj1.set(123.456);
		System.out.println(obj1.get());
		obj1.set(true);
		System.out.println(obj1.get());
		obj1.set('A');
		System.out.println(obj1.get());
				
		Inf1 obj1 = new Example1();
		obj1.print_info("First No", 5);
		obj1.newLine();
		obj1.print_info("Second No", 25);
		
		//Generics Constructor and Methods
		Example1 obj1 = new Example1(20);
		System.out.println(obj1.get());
		
		obj1.set(58);
		System.out.println(obj1.get());
		
		
		Example1 obj1 =  new Example1();
		obj1.add(5);
		obj1.add(9);
		obj1.add(4);
		obj1.add(3);
		obj1.add(1);
		obj1.printArray();
		*/
		
		
	}
}
