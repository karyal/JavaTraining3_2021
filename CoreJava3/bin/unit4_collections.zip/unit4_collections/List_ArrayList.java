package unit4_collections;

public class List_ArrayList {
	public static void main(String[] args) {
		//List
		//ArrayList
		//Declare, Initialize, Assign, Update, Access
		
	}
}
