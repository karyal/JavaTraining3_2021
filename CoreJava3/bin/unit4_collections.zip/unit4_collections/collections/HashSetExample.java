package collections.collections;

import java.util.HashSet;
import java.util.Set;

public class HashSetExample {
	public static void main(String[] args) {
		Set<String> hs=new HashSet<String>();
		hs.add("Apple");
		hs.add("Watermelon");		
		hs.add("Orange");
		hs.add("Pear");
		hs.add("Cherry");
		hs.add("Cherry");
		hs.add("Apple");
		hs.add("Strawberry");
		hs.add("Nectarine");
		hs.add("Grape");
		hs.add("Mango");		
		hs.add("Blueberry");
		hs.add("Pomegranate");
		hs.add("Orange");
		hs.add("Carambola");
		hs.add("starfruit");
		hs.add("Plum");
		hs.add("Lemon");
		hs.add("Banana");
		hs.add("Peach");
		hs.add("Raspberry");
		hs.add("Mandarin");
		hs.add("Jackfruit");
		hs.add("Papaya");
		hs.add("Kiwi");
		hs.add("Pineapple");
		hs.add("Lime");
		hs.add("Lemon");
		hs.add("Jackfruit");
		hs.add("Apricot");
		hs.add("Grapefruit");
		hs.add("Melon");
		hs.add("Coconut");
		hs.add("Avocado");
		hs.add("Peach");
		hs.add("Lemon");
		System.out.println(hs.size());		
	}
}
