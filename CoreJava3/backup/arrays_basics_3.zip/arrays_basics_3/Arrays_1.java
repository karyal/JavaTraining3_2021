package arrays_basics_3;

import basic_io.MyFunctions;

public class Arrays_1 {
	public static void main(String[] args) {
		// Basic Type - Value type
		// Value type - Stores Single Value
		// boolean byte, char, short, int, long, float, double 

		// Collections
		// Single variable can holds multiple values
		// Array, ArrayList 
		
		//f1();
		f2();
	}
	
	public static void f1() {
		//Declare array variable
		int num; //single valued variable		
		int nums[] = new int[5]; //multiple valued variable
		
		//Assing value
		num = 9;
		
		//Assign array
		nums[0] = 7;
		nums[1] = 2;
		nums[2] = 7;
		nums[3] = 6;
		nums[4] = 1;
		
		//Update
		num = 10;
		
		//Array Update
		nums[0] = 5;
		nums[1] = 3;
		nums[2] = 9;
		nums[3] = 1;
		nums[4] = 6;
		
		//Accessing single value variable
		System.out.println(num);
		
		//Accessing array varaible
		System.out.println(nums[0]);
		System.out.println(nums[1]);
		System.out.println(nums[2]);
		System.out.println(nums[3]);
		System.out.println(nums[4]);
		
		
	}
	
	public static void f2() {
		//Accept inputs
		int [] nums = new int [5];
		// |------ nums -----|-- Variable Name
		// [7] [ ] [10] [ ] [ ] -- Value
		//  0   1   2   3   4  -- Index
		
		//Direct value assign
		nums[2]=10;
		nums[0]=7;
		
		//Accept inputs from keyboard
		for(int i=0; i<5; i++) {
			MyFunctions.print("Enter Number : ");
			nums[i] = MyFunctions.readInt();
		}
		
		//Accessing values from array
		for(int i=0; i<5; i++) {
			MyFunctions.print("Number", nums[i]);
			MyFunctions.newLine();
		}
	}
}