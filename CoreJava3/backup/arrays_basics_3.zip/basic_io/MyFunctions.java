
package basic_io;

import java.util.Scanner;

public class MyFunctions {
	
	public static String readString() {
		return new Scanner(System.in).nextLine();
	}
	
	public static int readInt() {
		return Integer.parseInt(readString());
	}
	
	public static void print(String msg) {
		System.out.print(msg);
	}
	
	public static void print(String label, String msg) {
		System.out.print(label+" : "+msg);
	}
	
	public static void print(String label, int msg) {
		System.out.print(label+" : "+msg);
	}
	
	public static void newLine() {
		System.out.println();
	}
}
