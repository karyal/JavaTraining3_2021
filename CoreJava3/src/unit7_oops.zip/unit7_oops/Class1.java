package unit7_oops;

//Step
	//Class - like new type (data type-user defined)
	//Can have variables - optional
	//Can have methods (function) - optional
public class Class1 {
	
}