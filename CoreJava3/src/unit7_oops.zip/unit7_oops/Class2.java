package unit7_oops;

public class Class2 {
	//Variables
	int num1;
	int num2;
	int num3;
	//Methods
}